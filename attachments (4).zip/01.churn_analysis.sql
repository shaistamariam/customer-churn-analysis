---How many customers are present in the traing datset

SELECT COUNT(*) AS total_customers
FROM customer_churn_training;


---What subcription types are available?

SELECT DISTINCT subscription_type
FROM Customer_churn_training;

---How many customers are there in each subcription type?

SELECT 
    subscription_type,
    COUNT(*) AS customer_count
FROM customer_churn_training
GROUP BY subscription_type
ORDER BY customer_count DESC;

---What are the min,max,average customer spending values?

SELECT
    ROUND(MIN(total_spend), 2) AS minimum_spend,
    ROUND(MAX(total_spend), 2) AS maximum_spend,
    ROUND(AVG(total_spend), 2) AS average_spend
FROM customer_churn_training;

---What is the average tenure by subscription?

SELECT
    subscription_type,
    ROUND(AVG(tenure), 2) AS average_tenure
FROM customer_churn_training
GROUP BY subscription_type
ORDER BY average_tenure DESC;

---How many customer churned and how many stayed?

SELECT
    churn,
    COUNT(*) AS customer_count
FROM customer_churn_training
GROUP BY churn
ORDER BY churn;

---What is the overallchurn rate?

SELECT
    ROUND(
        100.0 * SUM(CASE WHEN churn = 1 THEN 1 ELSE 0 END)
        / COUNT(*),
        2
    ) AS churn_rate_percentage
FROM customer_churn_training;

---Which is the top 10 hightest spending customer?

SELECT
    customer_id,
    total_spend,
    subscription_type
FROM customer_churn_training
ORDER BY total_spend DESC
LIMIT 10;

---Which customer have the hightest number of support calls?

SELECT
    customer_id,
    support_calls,
    churn
FROM customer_churn_training
ORDER BY support_calls DESC
LIMIT 10;


--Which customer have payment delays greater than 10 days?

SELECT
    customer_id,
    payment_delay,
    churn
FROM customer_churn_training
WHERE payment_delay > 10
ORDER BY payment_delay DESC;


--Which customers have both High support calls and payment delays

SELECT
    customer_id,
    support_calls,
    payment_delay,
    churn
FROM customer_churn_training
WHERE support_calls >= 5
  AND payment_delay >= 10
ORDER BY support_calls DESC, payment_delay DESC;


---Which customers spend more than the average customers?

SELECT
    customer_id,
    total_spend
FROM customer_churn_training
WHERE total_spend > (
    SELECT AVG(total_spend)
    FROM customer_churn_training
)
ORDER BY total_spend DESC;


--Which subcriptions types have more than 50000 customers?

SELECT
    subscription_type,
    COUNT(*) AS customer_count
FROM customer_churn_training
GROUP BY subscription_type
HAVING COUNT(*) > 50000
ORDER BY customer_count DESC;


--Are there any Customer ID appering in both training and testing?

SELECT
    t.customer_id
FROM customer_churn_training t
INNER JOIN customer_churn_testing ts
    ON t.customer_id = ts.customer_id;

