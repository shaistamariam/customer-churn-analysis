CREATE TABLE customer_churn_testing (
    customerid BIGINT PRIMARY KEY,
    age INT,
    gender VARCHAR(20),
    tenure INT,
    usage_frequency INT,
    support_calls INT,
    payment_delay INT,
    subscription_type VARCHAR(50),
    contract_length VARCHAR(50),
    total_spend NUMERIC(12,2),
    last_interaction INT
);